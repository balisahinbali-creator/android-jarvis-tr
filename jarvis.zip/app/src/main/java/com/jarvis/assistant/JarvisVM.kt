package com.jarvis.assistant

import android.app.Application
import android.net.ConnectivityManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Msg(val role: String, val text: String)

class JarvisVM(app: Application) : AndroidViewModel(app) {
    val store = Store(app)
    private val llm = Llm(store)
    val msgs = mutableStateListOf<Msg>()
    val memories = mutableStateListOf<String>()
    var thinking by mutableStateOf(false)
    var listening by mutableStateOf(false)
    var level by mutableFloatStateOf(0f)
    var battery by mutableStateOf("--")
    var online by mutableStateOf(true)
    var screen by mutableStateOf("main")
    val voice = Voice(app) { level = it }
    private var job: Job? = null

    init {
        memories.addAll(store.memories())
        viewModelScope.launch {
            while (true) {
                battery = runCatching { Actions.batteryText(getApplication<Application>()).substringBefore(" (") }.getOrDefault("--")
                val cm = getApplication<Application>().getSystemService(ConnectivityManager::class.java)
                online = cm.activeNetwork != null
                delay(10000)
            }
        }
    }

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("d MMMM yyyy EEEE HH:mm", Locale.forLanguageTag("tr-TR")).format(Date())
        val mem = store.memories().joinToString("\n") { "- $it" }.ifEmpty { "(boş)" }
        return """Sen JARVIS'sin: kullanıcının Android telefonundaki kişisel yapay zeka asistanısın. Varsayılan dilin Türkçe, kullanıcı İngilizce yazarsa İngilizce yanıtla. Kısa, net ve doğal konuş.
Şu an: $now
Kullanıcı hafızası:
$mem

Cihazda iş yapmak için yanıtının SONUNA şu biçimde eylem ekleyebilirsin: [[ACTION:{"type":"...", ...}]]
Eylemler: open_app(arg=uygulama adı), open_url(arg), web_search(arg), navigate(arg=yer), set_alarm(hour,minute,label), set_timer(seconds,label), battery, time, device_info, remember(arg).
Kurallar:
- Eylemi yalnızca kullanıcı istediğinde ekle. Eylemin sonucunu sen bilmezsin; uygulama doğrular ve gösterir. Asla "yaptım" diye iddia etme, "başlatıyorum" de.
- battery, time, device_info eylemlerinde sayıyı kendin söyleme, uygulama gösterecek.
- remember eylemini yalnızca kullanıcı "hatırla" derse veya sorup onay alırsan kullan. Şifre, kart no gibi hassas bilgiyi asla kaydetme.
- Güncel bilgiyi uydurma; emin değilsen bunu söyle. Doğrulanmış bilgiyi tahminden ayır."""
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || thinking) return
        voice.stopSpeaking()
        msgs.add(Msg("user", t)); msgs.add(Msg("assistant", ""))
        val idx = msgs.lastIndex
        thinking = true
        job = viewModelScope.launch {
            val full = StringBuilder()
            var err: String? = null
            llm.chat(msgs.take(idx).takeLast(20).map { it.role to it.text }, systemPrompt())
                .catch { err = it.message ?: "Bilinmeyen hata" }
                .collect { d -> full.append(d); msgs[idx] = Msg("assistant", Actions.strip(full.toString())) }
            val raw = full.toString()
            val clean = Actions.strip(raw)
            val results = Actions.parse(raw).map { Actions.run(getApplication<Application>(), store, it) }
            memories.clear(); memories.addAll(store.memories())
            val extra = results.joinToString("\n") { "▸ ${it.status.uppercase()}: ${it.msg}" }
            val errText = err?.let { "⚠ Hata: $it" } ?: ""
            msgs[idx] = Msg("assistant", listOf(clean, extra, errText).filter { it.isNotEmpty() }.joinToString("\n\n").ifEmpty { "…" })
            thinking = false
            voice.speak((listOf(clean) + results.filter { it.status == "done" }.map { it.msg }).joinToString(". "), store.speed)
        }
    }

    fun cancel() { job?.cancel(); thinking = false; voice.stopSpeaking() }

    fun toggleMic() {
        if (listening) { voice.stopListening(); listening = false; level = 0f; return }
        voice.stopSpeaking()
        listening = true
        voice.listen(
            onFinal = { t -> listening = false; level = 0f; if (t.isNotBlank()) send(t) },
            onEnd = { listening = false; level = 0f }
        )
    }

    fun deleteMemory(i: Int) { store.deleteMemory(i); memories.clear(); memories.addAll(store.memories()) }
    fun addMemory(s: String) { store.addMemory(s); memories.clear(); memories.addAll(store.memories()) }
    override fun onCleared() { voice.release() }
}
