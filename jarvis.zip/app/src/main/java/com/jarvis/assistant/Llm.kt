package com.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL

class HttpEx(val code: Int, msg: String) : Exception("HTTP $code: $msg")

class Llm(private val store: Store) {

    private fun open(url: String, headers: Map<String, String>, body: String): BufferedReader {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        if (code != 200) {
            val e = c.errorStream?.bufferedReader()?.readText() ?: ""
            throw HttpEx(code, e.take(300))
        }
        return c.inputStream.bufferedReader()
    }

    fun chat(hist: List<Pair<String, String>>, system: String): Flow<String> = flow {
        if (store.apiKey.isBlank()) throw Exception("API anahtarı yok. AYARLAR bölümünden ekle.")
        if (store.provider == "gemini") {
            val first = store.model.ifBlank { "gemini-flash-lite-latest" }
            val models = listOf(first, "gemini-flash-lite-latest", "gemini-flash-latest").distinct()
            val attempts = models.flatMap { m -> if (store.grounding) listOf(m to true, m to false) else listOf(m to false) }
            var reader: BufferedReader? = null
            var last: Exception? = null
            for ((m, g) in attempts) {
                try {
                    val contents = JSONArray()
                    hist.forEach { (r, t) ->
                        contents.put(JSONObject().put("role", if (r == "user") "user" else "model")
                            .put("parts", JSONArray().put(JSONObject().put("text", t))))
                    }
                    val body = JSONObject()
                        .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                        .put("contents", contents)
                    if (g) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
                    reader = open(
                        "https://generativelanguage.googleapis.com/v1beta/models/$m:streamGenerateContent?alt=sse",
                        mapOf("x-goog-api-key" to store.apiKey), body.toString()
                    )
                    break
                } catch (e: HttpEx) {
                    last = e
                    if (e.code !in listOf(400, 404, 429, 500, 503)) throw e
                }
            }
            val r = reader ?: throw (last ?: Exception("Bağlantı kurulamadı"))
            r.use { rd ->
                var line = rd.readLine()
                while (line != null) {
                    if (line.startsWith("data:")) {
                        val text = runCatching {
                            val parts = JSONObject(line.removePrefix("data:").trim())
                                .optJSONArray("candidates")?.optJSONObject(0)
                                ?.optJSONObject("content")?.optJSONArray("parts")
                            val sb = StringBuilder()
                            if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                            sb.toString()
                        }.getOrDefault("")
                        if (text.isNotEmpty()) emit(text)
                    }
                    line = rd.readLine()
                }
            }
        } else {
            val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
            hist.forEach { (r, t) -> msgs.put(JSONObject().put("role", if (r == "user") "user" else "assistant").put("content", t)) }
            val body = JSONObject().put("model", store.model.ifBlank { "gpt-4o-mini" }).put("stream", true).put("messages", msgs)
            val r = open(store.baseUrl.trimEnd('/') + "/chat/completions",
                mapOf("Authorization" to "Bearer ${store.apiKey}"), body.toString())
            r.use { rd ->
                var line = rd.readLine()
                while (line != null) {
                    if (line.startsWith("data:")) {
                        val d = line.removePrefix("data:").trim()
                        if (d == "[DONE]") break
                        val text = runCatching {
                            JSONObject(d).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta")?.optString("content", "") ?: ""
                        }.getOrDefault("")
                        if (text.isNotEmpty()) emit(text)
                    }
                    line = rd.readLine()
                }
            }
        }
    }.flowOn(Dispatchers.IO)
}
