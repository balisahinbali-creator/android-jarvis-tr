package com.jarvis.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

val Cyan = Color(0xFF00E5FF)
val Blue = Color(0xFF2979FF)
val Bg = Color(0xFF020B14)
val PanelC = Color(0x2200E5FF)
val Mono = FontFamily.Monospace

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Bg, onSurface = Color(0xFFCFF8FF), onBackground = Color(0xFFCFF8FF))) {
                val vm: JarvisVM = viewModel()
                BackHandler(enabled = vm.screen != "main") { vm.screen = "main" }
                Box(Modifier.fillMaxSize().background(Bg).systemBarsPadding()) {
                    when (vm.screen) {
                        "settings" -> SettingsScreen(vm)
                        "memory" -> MemoryScreen(vm)
                        else -> MainScreen(vm)
                    }
                }
            }
        }
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(PanelC)
            .border(1.dp, Cyan.copy(alpha = 0.35f), RoundedCornerShape(14.dp)).padding(10.dp),
        content = content
    )
}

@Composable
fun Reactor(vm: JarvisVM, modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "r")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "rot")
    val ph by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(2000, easing = LinearEasing)), label = "ph")
    val lvl by animateFloatAsState(vm.level, label = "lvl")
    val base = when {
        vm.listening -> 0.15f + lvl * 0.85f
        vm.voice.speaking -> 0.6f
        vm.thinking -> 0.35f
        else -> 0.08f
    }
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2
        drawCircle(Cyan.copy(alpha = 0.25f), r * 0.97f, c, style = Stroke(2.dp.toPx()))
        rotate(rot, c) {
            for (s in listOf(0f, 180f)) drawArc(Cyan, s, 70f, false, c - Offset(r * 0.88f, r * 0.88f), Size(r * 1.76f, r * 1.76f), style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
        }
        rotate(-rot * 1.5f, c) {
            for (s in listOf(90f, 270f)) drawArc(Blue, s, 50f, false, c - Offset(r * 0.74f, r * 0.74f), Size(r * 1.48f, r * 1.48f), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        }
        val n = 48
        for (i in 0 until n) {
            val a = i.toFloat() / n * 2f * PI.toFloat()
            val amp = base * (0.5f + 0.5f * sin(ph * 3 + i * 0.5f))
            val r0 = r * 0.5f
            val r1 = r0 + r * 0.06f + r * 0.2f * amp
            drawLine(Cyan.copy(alpha = 0.8f), c + Offset(cos(a) * r0, sin(a) * r0), c + Offset(cos(a) * r1, sin(a) * r1), 2.dp.toPx(), StrokeCap.Round)
        }
        val rr = r * 0.34f * (1f + 0.1f * base * sin(ph * 2))
        drawCircle(Brush.radialGradient(listOf(Color.White, Cyan, Blue.copy(alpha = 0f)), center = c, radius = rr * 1.4f), rr * 1.4f, c)
    }
}

@Composable
fun StatusBar(vm: JarvisVM) {
    val m = vm.store.model.ifBlank { if (vm.store.provider == "gemini") "gemini-flash-lite-latest" else "gpt-4o-mini" }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("PİL ${vm.battery}", fontFamily = Mono, fontSize = 11.sp, color = Cyan)
        Text(if (vm.online) "AĞ ● ÇEVRİMİÇİ" else "AĞ ○ ÇEVRİMDIŞI", fontFamily = Mono, fontSize = 11.sp, color = if (vm.online) Cyan else Color(0xFFFF5252))
        Text(m.take(22), fontFamily = Mono, fontSize = 11.sp, color = Cyan)
    }
}

@Composable
fun Chat(vm: JarvisVM, modifier: Modifier) {
    val ls = rememberLazyListState()
    LaunchedEffect(vm.msgs.size, vm.msgs.lastOrNull()?.text?.length) {
        if (vm.msgs.isNotEmpty()) ls.animateScrollToItem(vm.msgs.lastIndex)
    }
    Glass(modifier) {
        if (vm.msgs.isEmpty()) Text("Sistem hazır. Komut ver, efendim.", fontFamily = Mono, color = Cyan.copy(alpha = 0.7f), fontSize = 13.sp)
        LazyColumn(state = ls, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.msgs.size) { i ->
                val m = vm.msgs[i]
                Column {
                    Text(if (m.role == "user") "SEN" else "JARVIS", fontFamily = Mono, fontSize = 10.sp, color = if (m.role == "user") Blue else Cyan)
                    Text(m.text.ifEmpty { "…" }, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun MainScreen(vm: JarvisVM) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) vm.toggleMic() }
    val onMic = {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.toggleMic()
        else launcher.launch(Manifest.permission.RECORD_AUDIO)
    }
    var input by remember { mutableStateOf("") }
    val state = when {
        vm.listening -> "DİNLİYOR"
        vm.thinking -> "DÜŞÜNÜYOR"
        vm.voice.speaking -> "KONUŞUYOR"
        else -> "HAZIR"
    }
    BoxWithConstraints(Modifier.fillMaxSize().padding(10.dp)) {
        val wide = maxWidth > 700.dp
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("J.A.R.V.I.S", fontFamily = Mono, fontSize = 20.sp, color = Cyan)
                Row { TextButton({ vm.screen = "memory" }) { Text("HAFIZA") }; TextButton({ vm.screen = "settings" }) { Text("AYARLAR") } }
            }
            Glass(Modifier.fillMaxWidth()) { StatusBar(vm) }
            if (wide) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Reactor(vm, Modifier.weight(1f).aspectRatio(1f))
                        Text(state, fontFamily = Mono, color = Cyan, letterSpacing = 4.sp)
                    }
                    Chat(vm, Modifier.weight(1f).fillMaxHeight())
                }
            } else {
                Reactor(vm, Modifier.align(Alignment.CenterHorizontally).height(190.dp).aspectRatio(1f))
                Text(state, fontFamily = Mono, color = Cyan, letterSpacing = 4.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                Chat(vm, Modifier.weight(1f).fillMaxWidth())
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Saat kaç?" to "Saat kaç ve bugün günlerden ne?", "Pil" to "Pil durumum nedir?", "Hava" to "Bugün hava nasıl?", "Haberler" to "Bugünün önemli haberleri neler?").forEach { (l, q) ->
                    AssistChip(onClick = { vm.send(q) }, label = { Text(l, fontFamily = Mono, fontSize = 12.sp) })
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    input, { input = it }, Modifier.weight(1f), placeholder = { Text("Komut yaz…") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { vm.send(input); input = "" })
                )
                Button(onMic) { Text(if (vm.listening) "■" else "MİK") }
                if (vm.thinking) Button({ vm.cancel() }) { Text("DUR") }
                else Button({ vm.send(input); input = "" }) { Text("➤") }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: JarvisVM) {
    val s = vm.store
    var provider by remember { mutableStateOf(s.provider) }
    var key by remember { mutableStateOf(s.apiKey) }
    var model by remember { mutableStateOf(s.model) }
    var base by remember { mutableStateOf(s.baseUrl) }
    var ground by remember { mutableStateOf(s.grounding) }
    var speed by remember { mutableFloatStateOf(s.speed) }
    Column(Modifier.fillMaxSize().padding(14.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("AYARLAR / API", fontFamily = Mono, color = Cyan, fontSize = 18.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(provider == "gemini", { provider = "gemini" }, { Text("Gemini") })
            FilterChip(provider == "openai", { provider = "openai" }, { Text("OpenAI uyumlu") })
        }
        OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text("API anahtarı (şifreli saklanır)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Model (boş = varsayılan)") }, singleLine = true)
        if (provider == "openai") OutlinedTextField(base, { base = it }, Modifier.fillMaxWidth(), label = { Text("Base URL") }, singleLine = true)
        else Row(verticalAlignment = Alignment.CenterVertically) { Switch(ground, { ground = it }); Spacer(Modifier.width(8.dp)); Text("Web araması (Gemini Google Search)") }
        Text("Konuşma hızı: %.1fx".format(speed))
        Slider(speed, { speed = it }, valueRange = 0.5f..1.8f)
        Button({
            s.provider = provider; s.apiKey = key; s.model = model; s.baseUrl = base; s.grounding = ground; s.speed = speed
            vm.screen = "main"
        }) { Text("KAYDET") }
        Text("Gemini anahtarı: aistudio.google.com. Anahtar yalnızca bu cihazda şifreli tutulur.", fontSize = 12.sp, color = Cyan.copy(alpha = 0.6f))
    }
}

@Composable
fun MemoryScreen(vm: JarvisVM) {
    var n by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("HAFIZA", fontFamily = Mono, color = Cyan, fontSize = 18.sp)
        Text("JARVIS sadece senin onayınla kaydeder. Buradan silebilirsin.", fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(n, { n = it }, Modifier.weight(1f), placeholder = { Text("Yeni bilgi ekle") }, singleLine = true)
            Button({ vm.addMemory(n); n = "" }) { Text("EKLE") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(vm.memories.size) { i ->
                Glass(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(vm.memories[i], Modifier.weight(1f))
                        TextButton({ vm.deleteMemory(i) }) { Text("SİL") }
                    }
                }
            }
        }
        if (vm.memories.isEmpty()) Text("Henüz kayıt yok.", color = Cyan.copy(alpha = 0.6f))
    }
}
